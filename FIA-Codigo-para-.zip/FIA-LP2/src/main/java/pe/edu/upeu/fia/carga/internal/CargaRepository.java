package pe.edu.upeu.fia.carga.internal;
import org.springframework.data.jpa.repository.*;
interface CargaRepository extends JpaRepository<Carga,Long>,JpaSpecificationExecutor<Carga> {}
