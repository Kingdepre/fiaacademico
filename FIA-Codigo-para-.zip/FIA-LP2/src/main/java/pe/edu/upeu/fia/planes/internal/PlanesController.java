package pe.edu.upeu.fia.planes.internal;
import pe.edu.upeu.fia.planes.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.*;
@io.swagger.v3.oas.annotations.tags.Tag(name="Plan de estudios")
@RestController @RequestMapping("/api/v1") class PlanesController {
 private final PlanesService service; PlanesController(PlanesService s){service=s;}
 @io.swagger.v3.oas.annotations.Operation(summary="Buscar docentes para autocompletado")
 @GetMapping("/docentes") List<DocenteDto> docentes(@RequestParam(defaultValue="") String buscar){return service.docentes(buscar);}
 @io.swagger.v3.oas.annotations.Operation(summary="Consultar planes de FIA")
 @GetMapping("/planes") List<PlanDto> planes(){return service.planes();}
 @io.swagger.v3.oas.annotations.Operation(summary="Filtrar cursos por plan, ciclo y nombre")
 @GetMapping("/cursos") List<CursoDto> cursos(@RequestParam(required=false) Long planId,@RequestParam(required=false) Integer ciclo,@RequestParam(required=false) String buscar,@RequestParam(defaultValue="cycle") String orden){return service.cursos(planId,ciclo,buscar,orden);}
 @io.swagger.v3.oas.annotations.Operation(summary="Consultar un curso")
 @GetMapping("/cursos/{id}") CursoDto curso(@PathVariable Long id){return service.curso(id);}
 @io.swagger.v3.oas.annotations.Operation(summary="Crear un curso")
 @PostMapping("/cursos") ResponseEntity<CursoDto> crear(@Valid @RequestBody CursoInput i){var c=service.guardar(null,i);return ResponseEntity.created(URI.create("/api/v1/cursos/"+c.id())).body(c);}
 @io.swagger.v3.oas.annotations.Operation(summary="Editar un curso")
 @PutMapping("/cursos/{id}") CursoDto editar(@PathVariable Long id,@Valid @RequestBody CursoInput i){return service.guardar(id,i);}
 @io.swagger.v3.oas.annotations.Operation(summary="Eliminar un curso sin referencias")
 @DeleteMapping("/cursos/{id}") ResponseEntity<Void> borrar(@PathVariable Long id){service.borrar(id);return ResponseEntity.noContent().build();}
 @io.swagger.v3.oas.annotations.Operation(summary="Resumir créditos y horas del plan")
 @GetMapping("/cursos/resumen") Map<String,Object> resumen(@RequestParam Long planId){var cs=service.cursos(planId,null,null,"cycle");return Map.of("cursos",cs.size(),"creditos",cs.stream().mapToInt(CursoDto::credits).sum(),"horas",cs.stream().mapToInt(CursoDto::total).sum());}
}
