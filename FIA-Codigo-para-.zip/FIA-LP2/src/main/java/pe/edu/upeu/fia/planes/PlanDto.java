package pe.edu.upeu.fia.planes;
public record PlanDto(Long id, String school, String version, String variant, String source) {}
