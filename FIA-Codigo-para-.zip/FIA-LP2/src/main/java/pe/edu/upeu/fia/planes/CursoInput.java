package pe.edu.upeu.fia.planes;
import jakarta.validation.constraints.*;
public record CursoInput(@NotNull Long planId,@Min(1) @Max(10) int cycle,@NotBlank @Size(max=300) String name,@Min(0) int credits,@Min(0) int ht,@Min(0) int hp,@Min(0) int hnp,@Size(max=3000) String prerequisites) {}
