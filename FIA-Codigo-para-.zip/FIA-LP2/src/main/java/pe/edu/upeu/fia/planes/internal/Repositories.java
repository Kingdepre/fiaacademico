package pe.edu.upeu.fia.planes.internal;
import org.springframework.data.jpa.repository.*;
interface PlanRepository extends JpaRepository<Plan,Long> {}
interface CursoRepository extends JpaRepository<Curso,Long>,JpaSpecificationExecutor<Curso> {}
interface DocenteRepository extends JpaRepository<Docente,Long> {}
