package pe.edu.upeu.fia.planes;
public record DocenteDto(Long id,String name,String course,String school) {}
