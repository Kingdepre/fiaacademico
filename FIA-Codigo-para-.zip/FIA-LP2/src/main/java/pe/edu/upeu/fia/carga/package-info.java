@org.springframework.modulith.ApplicationModule(allowedDependencies = {"planes"})
package pe.edu.upeu.fia.carga;
