package pe.edu.upeu.fia.infra;
import org.springframework.web.bind.annotation.*;import org.springframework.http.*;import org.springframework.web.bind.MethodArgumentNotValidException;import org.springframework.dao.DataIntegrityViolationException;import org.springframework.http.converter.HttpMessageNotReadableException;import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;import java.util.*;
@RestControllerAdvice class Errores {
 @ExceptionHandler(NoSuchElementException.class) ResponseEntity<ProblemDetail> missing(NoSuchElementException e){return error(404,e.getMessage());}
 @ExceptionHandler(IllegalArgumentException.class) ResponseEntity<ProblemDetail> invalid(IllegalArgumentException e){return error(400,e.getMessage());}
 @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<ProblemDetail> validation(MethodArgumentNotValidException e){return error(400,e.getBindingResult().getFieldErrors().stream().map(f->f.getField()+": "+f.getDefaultMessage()).reduce((a,b)->a+"; "+b).orElse("Datos inválidos"));}
 @ExceptionHandler({HttpMessageNotReadableException.class,MethodArgumentTypeMismatchException.class}) ResponseEntity<ProblemDetail> parse(Exception e){return error(400,"Formato de solicitud inválido");}
 @ExceptionHandler(DataIntegrityViolationException.class) ResponseEntity<ProblemDetail> conflict(Exception e){return error(409,"El registro está relacionado o incumple una restricción de integridad");}
 private ResponseEntity<ProblemDetail> error(int status,String detail){var problem=ProblemDetail.forStatusAndDetail(HttpStatusCode.valueOf(status),detail); var attributes=org.springframework.web.context.request.RequestContextHolder.getRequestAttributes(); if(attributes instanceof org.springframework.web.context.request.ServletRequestAttributes servlet){problem.setProperty("requestId",servlet.getRequest().getAttribute("requestId"));} return ResponseEntity.status(status).body(problem);}
}

