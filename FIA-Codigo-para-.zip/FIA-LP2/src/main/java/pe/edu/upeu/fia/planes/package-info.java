@org.springframework.modulith.ApplicationModule(allowedDependencies = {})
package pe.edu.upeu.fia.planes;
