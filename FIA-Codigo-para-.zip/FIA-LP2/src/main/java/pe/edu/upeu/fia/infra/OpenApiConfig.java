package pe.edu.upeu.fia.infra;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    OpenAPI fiaOpenAPI() {
        return new OpenAPI().info(new Info()
                .title("FIA Gestión Académica API")
                .version("1.0.0")
                .description("API para consultar planes de estudio y gestionar la carga académica de FIA")
                .contact(new Contact().name("Equipo FIA LP2")));
    }
}
