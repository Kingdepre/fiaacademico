package pe.edu.upeu.fia.planes.internal;
import pe.edu.upeu.fia.planes.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import java.util.*;
import java.text.Normalizer;
@Service @Transactional(readOnly=true)
class PlanesService implements PlanesApi {
 private final PlanRepository plans; private final CursoRepository courses; private final DocenteRepository teachers;
 PlanesService(PlanRepository p,CursoRepository c,DocenteRepository t){plans=p;courses=c;teachers=t;}
 static String norm(String s){return Normalizer.normalize(s,Normalizer.Form.NFD).replaceAll("\\p{M}","").toLowerCase(Locale.ROOT).trim();}
 PlanDto dto(Plan p){return new PlanDto(p.id,p.school,p.version,p.variant,p.source);}
 DocenteDto dto(Docente d){return new DocenteDto(d.id,d.name,d.course,d.school);}
 CursoDto dto(Curso c,List<Docente> ts){Plan p=org.hibernate.Hibernate.unproxy(c.plan,Plan.class);return new CursoDto(c.id,p.id,p.school,c.cycle,c.name,c.credits,c.ht,c.hp,c.hnp,c.total,c.prerequisites,c.notes,c.source,c.page,ts.stream().filter(t->t.school.equals(p.school)&&norm(t.course).equals(norm(c.name))).map(this::dto).toList());}
 public List<DocenteDto> docentes(String buscar){
  var unique=new java.util.TreeMap<String,DocenteDto>();
  for(var d:teachers.findAll()){String key=norm(d.name).replaceAll("[^a-z0-9]","");unique.putIfAbsent(key,dto(d));}
  String term=norm(buscar==null?"":buscar);
  return unique.values().stream().filter(d->norm(d.name()).contains(term)).sorted(java.util.Comparator.comparing(DocenteDto::name)).toList();
 }
 public List<PlanDto> planes(){return plans.findAll(Sort.by("school","version","variant")).stream().map(this::dto).toList();}
 public PlanDto plan(Long id){return dto(plans.findById(id).orElseThrow(()->new NoSuchElementException("Plan no encontrado")));}
 public DocenteDto docente(Long id){return dto(teachers.findById(id).orElseThrow(()->new NoSuchElementException("Docente no encontrado")));}
 public CursoDto curso(Long id){return dto(courses.findById(id).orElseThrow(()->new NoSuchElementException("Curso no encontrado")),teachers.findAll());}
 public List<CursoDto> cursos(Long planId,Integer ciclo,String buscar,String orden){
  if(!Set.of("name","cycle","credits").contains(orden)) throw new IllegalArgumentException("Orden permitido: name, cycle o credits");
  Specification<Curso> spec=(r,q,b)->{var ps=new ArrayList<jakarta.persistence.criteria.Predicate>();
   if(planId!=null)ps.add(b.equal(r.get("plan").get("id"),planId)); if(ciclo!=null)ps.add(b.equal(r.get("cycle"),ciclo));
   if(buscar!=null&&!buscar.isBlank()) {
    String term=buscar.toLowerCase(Locale.ROOT).replace("!","!!").replace("%","!%").replace("_","!_");
    ps.add(b.like(b.lower(r.get("name")),"%"+term+"%",'!'));
   }
   return b.and(ps.toArray(jakarta.persistence.criteria.Predicate[]::new));};
  var ts=teachers.findAll();return courses.findAll(spec,Sort.by(orden).and(Sort.by("id"))).stream().map(c->dto(c,ts)).toList();
 }
 @Transactional public CursoDto guardar(Long id,CursoInput i){
  Curso c=id==null?new Curso():courses.findById(id).orElseThrow(()->new NoSuchElementException("Curso no encontrado"));
  c.plan=plans.findById(i.planId()).orElseThrow(()->new NoSuchElementException("Plan no encontrado"));c.cycle=i.cycle();c.name=i.name().trim();c.credits=i.credits();c.ht=i.ht();c.hp=i.hp();c.hnp=i.hnp();c.total=Math.addExact(Math.addExact(c.ht,c.hp),c.hnp);c.prerequisites=i.prerequisites();
  c.source="Registro manual";c.page=0;c.notes="Ingresado o modificado por el usuario";return dto(courses.saveAndFlush(c),teachers.findAll());
 }
 @Transactional public void borrar(Long id){if(!courses.existsById(id))throw new NoSuchElementException("Curso no encontrado");courses.deleteById(id);courses.flush();}
}
