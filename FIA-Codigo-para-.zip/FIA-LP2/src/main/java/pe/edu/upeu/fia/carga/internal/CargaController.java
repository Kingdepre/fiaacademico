package pe.edu.upeu.fia.carga.internal;
import org.springframework.web.bind.annotation.*;import org.springframework.http.ResponseEntity;import jakarta.validation.Valid;import java.net.URI;import java.util.*;import java.time.*;import static pe.edu.upeu.fia.carga.internal.CargaDtos.*;
@io.swagger.v3.oas.annotations.tags.Tag(name="Carga académica")
@RestController @RequestMapping("/api/v1/cargas") class CargaController {
 private final CargaService service;CargaController(CargaService s){service=s;}
 @io.swagger.v3.oas.annotations.Operation(summary="Registrar cabecera y detalles de forma atómica")
 @PostMapping ResponseEntity<Dto> crear(@Valid @RequestBody Input i){var d=service.crear(i);return ResponseEntity.created(URI.create("/api/v1/cargas/"+d.id())).body(d);}
 @io.swagger.v3.oas.annotations.Operation(summary="Actualizar carga y validar cruces")
 @PutMapping("/{id}") Dto actualizar(@PathVariable Long id,@Valid @RequestBody Input i){return service.actualizar(id,i);}
 @io.swagger.v3.oas.annotations.Operation(summary="Generar propuestas de horarios faltantes")
 @PostMapping("/generar") List<Dto> generar(){return service.generar();}
 @io.swagger.v3.oas.annotations.Operation(summary="Consultar cargas con filtros combinados")
 @GetMapping List<Dto> listar(@RequestParam(required=false) Long planId,@RequestParam(required=false) String semestre,@RequestParam(required=false) LocalDate desde,@RequestParam(required=false) LocalDate hasta,@RequestParam(required=false) String estado,@RequestParam(defaultValue="fechaDesc") String orden){return service.listar(planId,semestre,desde,hasta,estado,orden);}
 @io.swagger.v3.oas.annotations.Operation(summary="Consultar una carga")
 @GetMapping("/{id}") Dto uno(@PathVariable Long id){return service.uno(id);}
 @io.swagger.v3.oas.annotations.Operation(summary="Resumir cargas, detalles y horas")
 @GetMapping("/resumen") Map<String,Object> resumen(@RequestParam(required=false) Long planId,@RequestParam(required=false) String semestre,@RequestParam(required=false) LocalDate desde,@RequestParam(required=false) LocalDate hasta,@RequestParam(required=false) String estado,@RequestParam(defaultValue="fechaDesc") String orden){var list=service.listar(planId,semestre,desde,hasta,estado,orden);return Map.of("cargas",list.size(),"detalles",list.stream().mapToInt(c->c.detalles().size()).sum(),"horas",list.stream().mapToInt(Dto::totalHoras).sum());}
}
