package pe.edu.upeu.fia.infra;
import org.springframework.stereotype.Component;import org.springframework.web.filter.OncePerRequestFilter;import jakarta.servlet.*;import jakarta.servlet.http.*;import java.io.IOException;import java.util.UUID;import org.slf4j.*;
@Component class RequestLog extends OncePerRequestFilter {
 private static final Logger log=LoggerFactory.getLogger(RequestLog.class);
 protected void doFilterInternal(HttpServletRequest req,HttpServletResponse res,FilterChain chain)throws ServletException,IOException{
  String id=req.getHeader("X-Request-ID");
  if(id==null) id=req.getHeader("X-Trace-ID");
  if(id==null || !id.matches("[A-Za-z0-9._-]{1,64}")) id=UUID.randomUUID().toString();
  req.setAttribute("requestId",id);
  res.setHeader("X-Request-ID",id);res.setHeader("X-Trace-ID",id);long start=System.nanoTime();
  try{chain.doFilter(req,res);}finally{log.info("request={} method={} path={} status={} durationMs={}",id,req.getMethod(),req.getRequestURI(),res.getStatus(),(System.nanoTime()-start)/1000000);}
 }
}
