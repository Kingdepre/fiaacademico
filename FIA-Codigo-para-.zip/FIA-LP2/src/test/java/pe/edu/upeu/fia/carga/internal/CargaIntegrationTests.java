package pe.edu.upeu.fia.carga.internal;
import pe.edu.upeu.fia.planes.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.jdbc.core.JdbcTemplate;
import java.util.*;
import static org.assertj.core.api.Assertions.*;
import static pe.edu.upeu.fia.carga.internal.CargaDtos.*;
@SpringBootTest @ActiveProfiles("test") class CargaIntegrationTests {
 @Autowired CargaService service; @Autowired PlanesApi planes; @Autowired JdbcTemplate db;
 CursoDto curso(){return planes.cursos(37L,1,null,"name").get(0);}
 Input input(List<DetalleInput> ds){return new Input(37L,"Filial Juliaca","PRUEBA-TRANSACCION","Escuela Profesional Pregrado",ds);}
 DetalleInput detalle(Long id,int grupo){return new DetalleInput(id,null,grupo,null,null,null,null,List.of());}
 long count(String table){return db.queryForObject("SELECT COUNT(*) FROM "+table,Long.class);}
 @Test void registraCabeceraDetallesYCalculaHoras(){var c=curso();var result=service.crear(input(List.of(detalle(c.id(),1),detalle(c.id(),2))));assertThat(result.id()).isNotNull();assertThat(result.detalles()).hasSize(2);assertThat(result.totalHoras()).isEqualTo(c.total()*2);assertThat(service.uno(result.id()).detalles()).hasSize(2);}
 @Test void falloEnSegundoDetalleRevierteCabeceraYPrimerDetalle(){long h=count("FIA_CARGA"),d=count("FIA_CARGA_DETALLE");assertThatThrownBy(()->service.crear(input(List.of(detalle(curso().id(),1),detalle(Long.MAX_VALUE,1))))).isInstanceOf(NoSuchElementException.class);assertThat(count("FIA_CARGA")).isEqualTo(h);assertThat(count("FIA_CARGA_DETALLE")).isEqualTo(d);}
 @Test void rechazaCursoDeOtroPlan(){var otro=planes.cursos(1L,1,null,"name").get(0);assertThatThrownBy(()->service.crear(input(List.of(detalle(otro.id(),1))))).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("no pertenece");}
 @Test void rechazaGrupoDuplicado(){var c=curso();long h=count("FIA_CARGA");assertThatThrownBy(()->service.crear(input(List.of(detalle(c.id(),1),detalle(c.id(),1))))).isInstanceOf(IllegalArgumentException.class);assertThat(count("FIA_CARGA")).isEqualTo(h);}
 @Test void rechazaBloquesSuperpuestos(){var c=curso();var d=new DetalleInput(c.id(),null,1,null,null,null,null,List.of(new BloqueInput(1,450,510),new BloqueInput(1,500,550)));assertThatThrownBy(()->service.crear(input(List.of(d)))).isInstanceOf(IllegalArgumentException.class).hasMessageContaining("superpuestos");}
 @Test void filtraCargasPorPlanSemestreYFecha(){var c=curso();var r=service.crear(input(List.of(detalle(c.id(),1))));assertThat(service.listar(37L,"PRUEBA-TRANSACCION",r.fecha().toLocalDate(),r.fecha().toLocalDate())).extracting(Dto::id).contains(r.id());assertThat(service.listar(1L,"PRUEBA-TRANSACCION",null,null)).isEmpty();}
}
