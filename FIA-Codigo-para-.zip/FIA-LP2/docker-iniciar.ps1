$ErrorActionPreference = 'Stop'
docker compose up -d
docker compose ps
Write-Host 'Oracle XE: localhost:1521/XEPDB1  usuario FIA_APP'
Write-Host 'Ejecuta: java -jar fia-academico-1.0.0.jar --spring.profiles.active=docker'
