# Ejecutar FIA en Visual Studio Code

1. Abre esta carpeta en VS Code.
2. Pulsa Ctrl + Shift + B para iniciar la tarea FIA.
3. Abre http://localhost:8087/.

La tarea ejecuta el JAR compilado con Java 17 y conserva la base de demostración de este equipo. Para detenerla, usa Terminar tarea. Los cambios en el código Java requieren recompilar el proyecto con Maven antes de ejecutar nuevamente el JAR.
