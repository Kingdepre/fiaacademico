# Plan de estudios y carga académica de FIA

Revisión del 27/09/2026: consultar [comparación con los proyectos y guía de entrega](docs/COMPARACION-Y-ENTREGA.md). La colección de práctica está incluida en `postman/FIA_U1.postman_collection.json`, con consultas de Swagger y correlación de errores. Mantiene `baseUrl=http://localhost:8089` para no escribir sobre una base de exposición por accidente.

Proyecto de LP2 con dos opciones de navegación: **Plan de estudios** y **Carga académica**. La interfaz se sirve desde el mismo ejecutable Spring Boot. Incluye 37 planes PDF de FIA y los datos extraídos del Word suministrado. No requiere una instalación de Node para ejecutarse.

## Ejecutar con Oracle

Requisitos: JDK 17 o posterior, Maven 3.9 y una instancia Oracle disponible. El proyecto utiliza Spring Boot 4.0.7 y Spring Modulith 2.0.7. Abrir esta carpeta como proyecto Maven en IntelliJ IDEA.

1. Ejecutar `database/oracle.sql` con el usuario de aplicación en un esquema vacío. El script no modifica otros esquemas ni crea usuarios.
2. Configurar las variables de entorno con los valores reales de su base de BD2:

```powershell
$env:ORACLE_URL = 'jdbc:oracle:thin:@//SERVIDOR:1521/SERVICIO'
$env:ORACLE_USER = 'USUARIO_DEL_ESQUEMA'
$env:ORACLE_PASSWORD = 'CONTRASENA_LOCAL'
$env:IMPORTAR_FUENTES = 'true'
mvn spring-boot:run
```

3. Abrir [la aplicación local](http://localhost:8080).

Los valores en mayúsculas son marcadores para reemplazar, no credenciales existentes. Las credenciales no se versionan. La importación está deshabilitada por defecto y únicamente se ejecuta cuando se habilita y la tabla de planes está vacía. Toda la importación se confirma en una transacción. Después de la primera importación, desactivar `IMPORTAR_FUENTES`.

### Oracle local con Docker

El archivo `docker-compose.yml` crea una instancia Oracle XE local, el usuario `FIA_APP` y un volumen persistente. Requiere Docker Desktop iniciado:

```powershell
docker compose up -d
docker compose ps
java -jar fia-academico-1.0.0.jar --spring.profiles.active=docker
```

La conexión es `jdbc:oracle:thin:@//localhost:1521/XEPDB1`. En el primer arranque se ejecuta `database/oracle.sql`. Para detener el contenedor usa `docker compose down`.

El esquema propuesto debe alinearse con el esquema real de BD2. No se recibió la conexión Oracle del equipo ni su DDL; la integración real de ADS y BD2 exige ejecutar y verificar la aplicación contra esa base. No se afirma que esa evidencia ya esté cumplida.

## Demostración local sin Oracle

El ZIP incluye `fia-academico-1.0.0.jar`. En Windows, ejecutar `iniciar-demo.cmd` y abrir [la aplicación local](http://localhost:8080). El iniciador usa `JAVA_HOME` o busca un JDK instalado en la carpeta `.jdks` del usuario. Requiere Java 17 o posterior.

Para iniciar desde el código fuente:

```powershell
mvn spring-boot:run '-Dspring-boot.run.profiles=demo'
```

Este perfil usa H2 persistente en `data/`, importa los mismos datos y muestra **Modo demostración · H2** en la cabecera. Sirve para revisar la interfaz y el flujo completo; no sustituye la evidencia Oracle exigida por el curso. No hay asignaciones inventadas al inicio.

## Uso

### Swagger / OpenAPI

Con el backend en ejecución, la documentación interactiva está disponible en:

- [Swagger UI](http://localhost:8080/swagger-ui.html)
- [Especificación OpenAPI](http://localhost:8080/v3/api-docs)

Si ejecutas la instancia Docker en el puerto 8081, usa `http://localhost:8081/swagger-ui.html`.

- **Plan de estudios:** elegir escuela, plan y ciclo; buscar cursos; consultar créditos, HT, HP, HNP, total y prerrequisitos; abrir el PDF original. Crear, editar y eliminar cursos mediante REST. Los cambios manuales se identifican como tales.
- **Carga académica:** seleccionar los tres filtros mostrados en las capturas, abrir una escuela y elegir el plan. Las cinco carreras tienen cargas generadas y guardadas al iniciar demo. Editar filas, aumentar cupos, añadir grupos y asignar docentes desde el autocompletado global. Guardar valida los cruces de docente, ambiente y ciclo/grupo. Los horarios y ambientes son propuestas editables. Consultar las cargas registradas y su horario semanal.
- Los cambios de asignación se conservan primero en el borrador en memoria. **Guardar carga** los envía al backend y confirma la cabecera y los detalles en la base de datos.
- El calendario es semanal, sin fechas de vigencia precargadas: no se entregó una programación completa por fechas.

## Fuentes y alcance

Consultar `docs/fuentes-y-alcance.md`, `docs/brief.md` y `docs/lp2-demo.md`.

No se incorporaron JWT, microservicios, matrícula, pagos, otras facultades, usuarios ficticios ni estadísticas de estudiantes. Los valores ausentes se representan como «—», «Sin asignar» o campos vacíos; no como cero.

## Pruebas y empaquetado

```powershell
mvn test
mvn package
java -jar target/fia-academico-1.0.0.jar --spring.profiles.active=demo
```

Las pruebas automáticas usan H2 en memoria y datos de prueba identificados por `FIXTURE` o `PRUEBA-TRANSACCION`. Comprueban límites modulares, CRUD, filtros combinados, validaciones, CORS y rollback después de insertar la cabecera y un primer detalle. Revisar `docs/VALIDACION.md` para el resultado de ejecución de esta entrega.

## Organización

```text
src/main/java/pe/edu/upeu/fia/
  FiaApplication.java
  planes/                 API pública del catálogo
    internal/             Entidades, repositorios, servicio y controller
  carga/
    internal/             Cabecera, detalles, horario, servicio y controller
  infra/                  CORS, errores, logs y estado
src/main/resources/static/ Interfaz HTML, CSS y JavaScript y PDF originales
database/oracle.sql        DDL propuesto para el esquema de aplicación
src/test/                  Pruebas automáticas
```

Un proyecto Maven, una JVM y un datasource. Carga utiliza `PlanesApi`; no accede a los repositorios del catálogo. Se usa HTML/CSS/JavaScript para la interfaz porque los enlaces no exigen un framework de frontend.
