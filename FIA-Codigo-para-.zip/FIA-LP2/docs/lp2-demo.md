# FIA - Producto de Unidad 1 de LP2

Fuente consultada el 13/09/2026: https://262ciclo4.github.io/bomerp/proyecto-integrador/u1/lp2-demo/

## 1. Estado de preparación

Equipo: Canaza Quisocala Frank Vladimir; Choquecota Centon Joseph Rodrigo; Mamani Jaila Jusephy Dalbert. Número de equipo y repositorio: pendientes de confirmar.

Se revisó la guía LP2 - Producto de Unidad 1 el 13 de septiembre de 2026. BomERP es el ejemplo: FIA mantiene planes y carga como sus módulos de negocio. No se añaden compras, ventas monetarias ni JWT; la guía sitúa JWT en Unidad 2.

Comprobado hoy: 22 pruebas automatizadas del backend y 15 comprobaciones HTTP, sin fallos. El ensayo usa H2 en memoria en el puerto 8089. La instancia de VS Code en 8080 conserva sus datos y no fue usada para crear las cargas de ensayo.

El proyecto preparado está en outputs/FIA-LP2. La carpeta Downloads/FIA-LP2-actualizado abierta en VS Code es otra copia: no se sobrescribió. Los filtros nuevos deben ejecutarse desde la copia preparada o trasladarse después de revisar diferencias.

Pendientes para una entrega completa: conexión y demostración Oracle, publicación de documentación, repositorio con topics/commits reales y correspondencia con los objetos de ADS/BD2 del equipo. La sustentación individual no se sustituye con pruebas automáticas.

| Archivo del material | Uso |
| --- | --- |
| LEEME.html | Entrada a documentación, presentación, colección y evidencias. |
| documentacion/index.html | Documentación navegable equivalente; lista para publicar. |
| presentacion.html | Apoyo visual de seis diapositivas para el pitch. |
| FIA_U1.postman_collection.json | Peticiones ordenadas con variables y verificaciones. |
| ensayar_api.py | Ensayo real de 15 comprobaciones con evidencia JSON. |
| evidencias/ | Reportes Surefire y solicitudes/respuestas del ensayo. |

## 2. Matriz de la rúbrica

Los cinco criterios técnicos pesan 16% cada uno; la sustentación pesa 20%. Esta matriz señala evidencia y límites; no inventa una calificación del jurado ni acredita Oracle con H2.

La demostración se concentra en una operación cabecera-detalle completa: Carga y DetalleCarga. Las horas se calculan en el servidor y los cruces se verifican dentro de la transacción.

| Criterio / peso | Evidencia preparada y límite |
| --- | --- |
| 1. Backend, ORM, conexión y API / 16% | Un POM, Java 17, Spring Boot, JPA, /api/v1 y contrato. Estado OK en demo. Oracle real pendiente. |
| 2. CRUD y aspectos transversales / 16% | Cursos: POST 201, GET 200, PUT 200, DELETE 204; error 400 y 404; X-Request-ID; CORS permitido y rechazado. |
| 3. Objetos relacionados / 16% | Plan-Curso, Carga-Detalle y bloques; DTO relacionado; pertenencia del curso al plan. |
| 4. Operación atómica / 16% | Dos detalles válidos y total calculado; segunda línea con choque devuelve 400 y mantiene conteos. Rollback de actualización conserva cupos. |
| 5. Consultas y CORS / 16% | Plan, semestre, estado, fecha y orden combinados; resumen agregado; CORS por propiedad. |
| 6. Sustentación / 20% | Guion, presentación y preguntas preparados. Autoría/aporte individual, repositorio, publicación, puntualidad y comunicación deben demostrarse por el equipo. |

## 3. Arquitectura y trazabilidad

pe.edu.upeu.fia contiene FiaApplication, planes, carga e infra. Es una JVM y un datasource. No hay Feign ni HTTP entre módulos. La interfaz web se sirve como recursos estáticos de la misma aplicación.

CargaService depende de PlanesApi. Los repositorios de planes.internal no se comparten. carga/package-info.java permite la dependencia planes; ModularityTests ejecuta ApplicationModules.verify().

En planes: Plan, Curso y Docente, servicio, controlador y repositorios internos. En carga: Carga, DetalleCarga, Bloque, CargaDtos, servicio, controlador y repositorio. infra maneja errores, CORS, estado y registros de solicitudes.

El código mantiene estado REGISTRADA; consultar otro estado devuelve lista vacía. No existe un flujo de anulación o aprobación. El docente se asigna manualmente y los ambientes generados son propuestas.

| LP2 | Vínculo ADS / BD2 y estado |
| --- | --- |
| Perfiles y datasource | ADS: un ejecutable y configuración externa. BD2: ORACLE_URL, ORACLE_USER y ORACLE_PASSWORD; sin secretos en Git. Conexión real pendiente. |
| Límites de módulos | ADS: diagrama de componentes/paquetes preparado. BD2: propiedad funcional de FIA_PLAN/FIA_CURSO y FIA_CARGA/FIA_CARGA_DETALLE. Validación con diseño del equipo pendiente. |
| Total y cruce de horario | ADS: regla de integridad. BD2: CHECK/FK/UNIQUE en oracle.sql. El cruce está implementado en Java; no se proporcionó PL/SQL del equipo. |
| Consulta por fecha | ADS: necesidad de consulta. BD2: índice IX_CARGA_FECHA incluido; rendimiento en Oracle no medido. |

## 4. Contrato REST del proyecto

Prefijo /api/v1. Las entradas usan DTO y las respuestas no exponen repositorios ni entidades JPA. Los errores usan ProblemDetail; guardar una carga con un choque devuelve 400 en esta implementación.

Los filtros de cargas se pueden combinar: planId, semestre, estado, desde y hasta (YYYY-MM-DD). El parámetro orden acepta fechaAsc, fechaDesc, horasAsc y horasDesc; el valor por defecto es fechaDesc. El resumen recibe los mismos filtros.

La búsqueda de docentes es global; no asigna automáticamente profesores ni representa disponibilidad contractual oficial.

| Método / recurso | Propósito y respuesta habitual |
| --- | --- |
| GET /estado | SELECT 1 FROM DUAL; perfil y conexión OK. |
| GET /planes | Planes disponibles de las cinco carreras. |
| GET /cursos | Filtros planId/ciclo/buscar; orden=name, cycle o credits. |
| GET /cursos/{id} | Curso, plan y datos asociados; 404 si no existe. |
| POST /cursos | Crear maestro: 201 y Location. |
| PUT /cursos/{id} | Editar y recalcular total: 200. |
| DELETE /cursos/{id} | 204; 409 cuando existe una referencia que impide borrar. |
| GET /cursos/resumen?planId=37 | Cantidad de cursos, créditos y horas. |
| GET /docentes?buscar=apellido | Autocompletado global de docentes. |
| POST /cargas | Cabecera y detalles en una transacción: 201. |
| PUT /cargas/{id} | Actualizar de forma atómica: 200. |
| GET /cargas y /cargas/{id} | Lista filtrada y consulta individual. |
| GET /cargas/resumen | Cantidad de cargas, detalles y horas. |
| POST /cargas/generar | Generación de propuestas faltantes; conserva las cargas existentes. |

## 5. Ejecución y ensayo seguro

Requisitos: Java 17 o posterior para el JAR; Maven para compilar el código; Python 3 estándar para el ensayo automático. El archivo .cmd del kit busca el proyecto FIA-LP2 junto a esta carpeta y también admite indicarle su ruta.

1. Ejecuta iniciar-ensayo.cmd. Inicia el JAR actualizado en 8089 y una base H2 en memoria. Espera el mensaje Started FiaApplication y la carga inicial de los datos.

2. Ejecuta ensayar_api.py con la opción de confirmación indicada. Crea un curso temporal (que luego elimina) y cargas de práctica con un semestre U1 único. Escribe las respuestas en evidencias/. Al detener la instancia se pierde la base de ensayo, pero el archivo de evidencia permanece.

3. Para la demostración normal con datos guardados, usa la tarea FIA: iniciar aplicación o iniciar-demo.cmd del proyecto. Para ensayar, usa 8089. No ejecutes el ensayo contra Oracle institucional ni contra 8080 sin haber elegido expresamente una base de práctica.

La compilación en este entorno requirió el administrador de archivos JavaCompiler descrito en docs/VALIDACION.md por una restricción de rutas Windows. Surefire ejecutó las 22 pruebas y Maven empaquetó el JAR. En VS Code local se conserva el POM Maven convencional.

### Desde la carpeta de este kit

```text
python ensayar_api.py --base http://localhost:8089
  --confirmar-base-practica
# Escribe ambas líneas como un solo comando.
```

### Desde la carpeta FIA-LP2

```text
mvn test
mvn package
java -jar fia-academico-1.0.0.jar --spring.profiles.active=demo
```

## 6. Guion de demostración técnica

Duración propuesta de ensayo: 12 minutos. Ajustar al tiempo que asigne el docente. La introducción ejecutiva precede a la demostración técnica; las diapositivas no la reemplazan.

Cada integrante debe explicar su aporte real y abrir el código correspondiente. La distribución siguiente es una propuesta de preparación, no una afirmación de autoría de los commits.

| Momento / responsable propuesto | Acción y frase clave |
| --- | --- |
| 0:00-1:30 / Frank | Pitch: problema, dos módulos y avance. «Aplicamos el patrón de venta/detalle a carga académica y sus cursos». |
| 1:30-3:30 / Frank | Mostrar pom.xml, estructura y PlanesApi. GET estado y planes. CRUD completo de un curso de ensayo; demostrar DTO inválido y X-Request-ID. |
| 3:30-5:30 / Joseph | Abrir Carga y DetalleCarga. Crear dos filas válidas; mostrar estado REGISTRADA, total calculado y consulta persistida. |
| 5:30-7:30 / Joseph | Mostrar resumen antes. Enviar dos filas con un choque en la segunda; HTTP 400. Repetir resumen: sin nuevos detalles ni cabecera. Explicar saveAndFlush frente a commit. |
| 7:30-9:30 / Jusephy | Combinar estado/semestre/fecha y cambiar orden. Mostrar resumen. Ejecutar OPTIONS permitido y rechazado; explicar CORS por propiedad. |
| 9:30-11:00 / Jusephy | Mostrar ModularityTests y resultado de 22 pruebas. Explicar bloqueo de agenda, reglas de servicio y rollback de actualización. |
| 11:00-12:00 / equipo | Mostrar trazabilidad, documentación y pendientes reales. Si Oracle sigue pendiente, decirlo expresamente; no afirmar integración completa. |

## 7. Preguntas para practicar



| Pregunta del jurado | Respuesta que deben comprender |
| --- | --- |
| ¿Por qué monolito modular? | Un ejecutable/JVM/datasource con límites de paquetes verificados. No son microservicios ni módulos Maven separados. |
| ¿Para qué un DTO? | Define el contrato de entrada/salida y sus validaciones; evita serializar entidades y relaciones diferidas directamente. |
| ¿Dónde se calcula el total? | En CargaService: por fila HT + HP + HNP; la cabecera suma esas horas. Cupos no multiplica horas. |
| ¿Qué hace cascade y orphanRemoval? | La cabecera administra persistencia y eliminación de sus líneas. No significa que una excepción confirme datos parciales. |
| ¿saveAndFlush confirma? | No. Sincroniza con la base; el commit ocurre al finalizar correctamente la transacción. |
| ¿Por qué el error provoca rollback? | La excepción unchecked sale del método público @Transactional. Spring revierte cabecera y detalles de esa operación. |
| ¿Por qué el cruce no va solo en el DTO? | Necesita comparar cargas guardadas, recursos y tiempos dentro de la transacción. @Min valida forma, no disponibilidad. |
| ¿Qué pasa con dos guardados a la vez? | La fila de AgendaLock se lee con PESSIMISTIC_WRITE y serializa escrituras antes de comprobar cruces. |
| ¿Por qué error 400 y no 409? | El servicio usa IllegalArgumentException para conflictos de horario; Errores la mapea a 400. Restricciones de integridad se mapean a 409. La guía admite 400/409. |
| ¿CORS es autenticación? | No. Es una política del navegador sobre orígenes. No protege de clientes que envían peticiones fuera del navegador. JWT corresponde a U2. |
| ¿H2 acredita Oracle? | No. H2 permite ensayar; el perfil, driver y DDL Oracle están preparados, pero se debe verificar el servidor Oracle real. |
| ¿Qué no está implementado? | JWT, aprobaciones, anulación, validación contractual docente, capacidad oficial de aulas y PL/SQL institucional. |

## 8. Oracle, repositorio y publicación

Oracle: usar un esquema de práctica acordado con BD2. En instalación nueva ejecutar database/oracle.sql una sola vez; en una instalación anterior revisar migracion-v2-oracle.sql. No ejecutar ambos indiscriminadamente. No se creó ni modificó un servidor Oracle durante esta preparación.

Configurar ORACLE_URL, ORACLE_USER y ORACLE_PASSWORD en variables del entorno local, sin versionar secretos. Para importar catálogo en un esquema vacío: IMPORTAR_FUENTES=true. Iniciar con --spring.profiles.active=oracle. Para preparar cargas faltantes puede utilizarse POST /api/v1/cargas/generar.

Verificación Oracle: estado debe mostrar perfil oracle y conexión OK; demostrar CRUD, carga y rollback contra esa misma base. Ejecutar verificar-oracle.sql para revisar tablas, índice y conteos. Registrar resultados reales y contrastar el DDL con BD2.

Repositorio: faltan URL y número de equipo. Revisar cambios, pruebas y un commit real de cada aporte; no fabricar historial. Los topics deben ser los académicos que indicó S2; no se recibieron sus valores exactos.

Publicación: documentacion/index.html funciona sin servidor. Su carpeta puede publicarse como sitio estático equivalente a MkDocs. En el repositorio acordado, copiar la carpeta a docs/ y configurar GitHub Pages para servirla. Antes, resolver el contenido si ya existe docs/; no reemplazar documentación del equipo sin revisarla.

La publicación y su URL no se han realizado porque no se proporcionó repositorio/destino. El archivo local no satisface por sí solo el requisito de documentación publicada.

Checklist de cierre: Oracle verificado; GitHub y topics reales; documentación en URL pública; demo ensayada; cada integrante identifica su contribución; capturas reales si el docente las solicita; puntualidad y presentación personal apropiada.

