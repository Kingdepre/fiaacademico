# Validación de la entrega

## Revisión del 27 de septiembre de 2026

**26 pruebas ejecutadas: 0 fallos, 0 errores, 0 omitidas.** Incluyen las pruebas existentes de CRUD, agenda, rollback, consultas y modularidad, y cuatro comprobaciones nuevas de Swagger y trazabilidad HTTP/CORS. La sintaxis de `static/app.js` pasó `node --check`.

Se compilaron las 31 unidades principales y las cinco unidades de pruebas con el procedimiento JavaCompiler ya descrito más abajo. La compilación convencional volvió a fallar por `AccessDeniedException` del entorno Windows; no fue un resultado exitoso de `mvn test`. Después de compilar, Maven ejecutó `resources:testResources surefire:test jar:jar spring-boot:repackage` con **BUILD SUCCESS**, generando el ejecutable desde las clases verificadas y resolviendo sus dependencias normalmente. No se utilizó el parche manual del JAR de la revisión anterior.

Los informes de esta ejecución están en `evidencias-20260927/`. Las pruebas utilizan H2; Oracle no se ha vuelto a verificar en esta revisión. Los resultados históricos siguientes conservan su fecha y alcance.

Fecha: 7 de septiembre de 2026.

## Datos

- 37 archivos PDF originales de cinco escuelas de FIA incluidos.
- 2638 registros de cursos de los distintos planes; identificadores únicos.
- 370 totales de ciclo comparados con los PDF: todos coinciden en créditos, HT, HP, HNP y horas totales.
- 392 relaciones de docentes y cursos extraídas de los bloques inequívocos del Word. Las coincidencias con los planes no se presentan como asignaciones vigentes.
- Verificada la existencia de cada PDF referenciado y la capacidad de los campos para conservar los textos extraídos completos.

## Backend

**20 pruebas ejecutadas; 0 fallos, 0 errores y 0 omitidas.**

| Grupo | Pruebas | Resultado |
|---|---:|---|
| AgendaIntegrationTests | 6 | Correcto |
| CargaIntegrationTests | 6 | Correcto |
| HttpIntegrationTests | 4 | Correcto |
| ModularityTests | 1 | Correcto |
| PlanesIntegrationTests | 3 | Correcto |

Se comprobaron registro de cabecera y detalles, cálculo del total, rollback tras persistir el primer detalle, rechazo de cursos de otro plan, rechazo de grupos repetidos y bloques superpuestos, filtros de cargas, CRUD de cursos, filtros combinados, validación HTTP 400, trazabilidad, CORS permitido y rechazado, entrega de la interfaz y estado de conexión. Spring Modulith verificó los límites de acceso entre módulos.

Las pruebas se ejecutaron con H2 en memoria, en modo Oracle y con una base independiente por contexto. Los reportes originales de Maven Surefire están en `pruebas/`.

La compilación estándar de Maven encontró una restricción del entorno Windows al resolver las rutas de los archivos JAR (`AccessDeniedException` en `toRealPath`). Para verificar el código se utilizó el compilador JDK 17 mediante la API JavaCompiler con las mismas dependencias resueltas por Maven, un administrador de archivos que lee las clases permitidas y sin procesadores de anotaciones. Compilaron las 30 unidades de código principal y las cinco de pruebas. Luego Maven Surefire ejecutó las 20 pruebas normalmente. Este ajuste se limitó al entorno de verificación; el proyecto conserva un POM Maven convencional.

Maven Jar Plugin y Spring Boot Repackage finalizaron con **BUILD SUCCESS**. Se incluye el ejecutable `fia-academico-1.0.0.jar`, con las dependencias necesarias para iniciarlo con Java 17 o posterior.

## Interfaz

La sintaxis de JavaScript pasó `node --check`. La prueba HTTP comprobó la respuesta 200 de la página servida por Spring Boot. La interfaz usa las dos opciones solicitadas, los datos originales y estilos basados en las capturas. No se afirma una prueba automatizada de clics ni una comparación visual píxel por píxel.

## Límite de la evidencia

No se recibió una conexión ni un esquema del equipo de BD2. El DDL y el perfil Oracle están preparados, pero su ejecución contra Oracle real **está pendiente**. H2 no sustituye esa parte de la sustentación. Tampoco se acredita aprobación docente, integración con un modelo ADS no proporcionado ni autenticación institucional.

La actualización verifica generación idempotente de cinco carreras, ausencia de cruces por ciclo, conflictos de docentes y ambientes entre cargas, edición de cupos, rollback de una actualización conflictiva y búsqueda/asignación global de docentes. Se añadieron 23 registros de nombres del bloque ambiguo al catálogo global sin inferir carrera.
