# Brief técnico del proyecto FIA

## Datos del equipo

Nombre del equipo, sección, integrantes, cursos de cada integrante, repositorio y topics: **pendientes de completar por el equipo**. No se asigna autoría ficticia.

## Dominio

**Proyecto:** Plan de estudios y carga académica de FIA.

**Necesidad:** consultar los planes de FIA y preparar una carga académica que relacione sus cursos con grupos, docentes y horarios ingresados. Los datos curriculares proceden del ZIP; las relaciones de docentes, del Word.

**Actor del alcance:** persona que consulta los planes y prepara la carga desde la interfaz de gestión. El nombre institucional del rol está pendiente de confirmar. En U1 no se implementa autenticación.

Continuidad de un proyecto anterior: no informada.

## Módulos

**Plan de estudios — módulo no transaccional de referencia.** Entidades Plan y Curso; relación de docentes documentada como catálogo auxiliar del mismo módulo.

1. El sistema debe listar las escuelas y planes de FIA presentes en los PDF.
2. El sistema debe consultar y mantener cursos asociados a un plan con DTO validado y manejo de errores.
3. El sistema debe filtrar cursos por plan, ciclo y nombre y mostrar créditos, horas y origen documental.

**Carga académica — módulo transaccional.** Cabecera Carga y colección DetalleCarga; bloques horarios asociados a cada detalle.

1. El sistema debe registrar en una operación la cabecera y todos sus detalles.
2. El sistema debe comprobar que cada curso pertenece al plan seleccionado y evitar repetir curso y grupo dentro de la carga.
3. El sistema debe calcular el total de horas a partir de los cursos y revertir la operación completa si falla un detalle.
4. El sistema debe permitir consultar las cargas mediante filtros y un resumen agregado.

Asignación de ambos módulos a integrantes: pendiente de completar. Si el equipo tiene más de un integrante, este alcance de dos módulos no satisface por sí solo la regla de dos módulos por integrante; se deberá acordar la distribución con el docente, sin ampliar automáticamente esta entrega.

## Alcance

Incluye solamente las dos opciones solicitadas, sus servicios REST y la persistencia propuesta en Oracle. Fuera de alcance: otras facultades, matrícula, pagos, JWT, reglas de contratación no documentadas y programación oficial no proporcionada.

Arquitectura inicial: un monolito modular Spring Boot con un datasource; Carga llama a la API pública de Planes. Objetos Oracle y contrato REST en `database/oracle.sql` y `lp2-demo.md`.

## Aprobación

Docentes ADS, BD2 y LP2 y fecha: pendientes. Este documento no implica aprobación institucional.
