# Validación de preparación U1 - 13/09/2026

Se agregó filtro estado y orden fechaAsc/fechaDesc/horasAsc/horasDesc a la lista de cargas y su resumen. Los demás contratos se preservan.

- 22 pruebas Surefire: 0 fallos, 0 errores, 0 omitidas.
- 15 comprobaciones HTTP reales sobre H2 en memoria: CRUD, DTO inválido, cabecera-detalle válida, rollback por choque en segunda línea, actualización de cupos, rollback de edición, filtros, agregaciones y CORS.
- 17 peticiones de la colección Postman y sus aserciones verificadas con un ejecutor HTTP en Node. No se ejecutó la interfaz de Postman; se conserva la evidencia JSON.
- JAR recompilado con Java 17 y empaquetado por Maven Jar Plugin y Spring Boot Repackage.
- Compilación con el mismo administrador de archivos JavaCompiler descrito en VALIDACION.md, por la restricción de rutas del entorno.
- La copia abierta de Downloads y sus datos no se modificaron.
- Oracle real, publicación, repositorio y trazabilidad con los objetos del equipo siguen pendientes.

Los reportes de la ejecución actual están en Preparacion_U1_FIA/evidencias/. Los reportes anteriores del proyecto se conservan como evidencia histórica.
