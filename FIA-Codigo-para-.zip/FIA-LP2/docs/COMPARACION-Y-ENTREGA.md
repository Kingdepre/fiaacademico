# FIA Académico: comparación y preparación de entrega

Revisión: 27 de septiembre de 2026.

## Alcance acordado

Se conserva la interfaz HTML, CSS y JavaScript y los dos módulos funcionales: Plan de estudios y Carga académica. El usuario confirmó que no se requiere migración a Angular. Las fuentes académicas de FIA siguen siendo las proporcionadas originalmente.

## Qué aportan los proyectos de referencia

| Referencia | Contenido revisado | Aplicación a FIA |
|---|---|---|
| AgroPeruvianFoods-main.zip | Backend Spring Boot, controladores, DTO, JPA, servicios transaccionales, Swagger y filtro de correlación | FIA ya tiene estas capas y operaciones. Se completa la documentación de operaciones Swagger y la correlación de solicitudes. |
| LP2-CICLO4-PROJECT-main.zip | Angular: rutas, formularios/listado de categorías, servicio HTTP y un interceptor X-Trace-ID | Se conserva la interfaz actual. Se aplica la trazabilidad a su función HTTP central y se admite X-Trace-ID para interoperar con clientes semejantes. |

Los ejemplos tratan productos, ventas, compras y categorías. Sus entidades y registros no corresponden al dominio académico y no se importan a las tablas FIA. Tampoco se deduce que toda dependencia de un ejemplo sea un requisito del curso: FIA comprueba la conexión mediante GET /api/v1/estado.

## Cambios de esta revisión

- Swagger identifica Plan de estudios y Carga académica, con nombres de operaciones en español.
- El navegador envía un identificador por petición. El backend conserva X-Request-ID o, en su ausencia, X-Trace-ID; admite letras, números, punto, guion y guion bajo hasta 64 caracteres. Si no es válido, genera un UUID.
- Las respuestas devuelven ambos encabezados de correlación. Los errores ProblemDetail incluyen requestId para relacionarlos con el registro del servidor.
- CORS permite ambos encabezados y expone Location para clientes de otros orígenes autorizados.
- Se añaden pruebas de Swagger, correlación en errores, sustitución de identificadores inválidos y preflight CORS.
- Se restablece target como carpeta estándar de compilación Maven para coincidir con las instrucciones de ejecución.

## Correspondencia con la guía de Unidad 1

Base: copia local de la guía consultada el 13/09/2026, en docs/lp2-demo.md. El enlace público no pudo recuperarse durante esta revisión; no se afirma que esta sea una nueva rúbrica de Unidad 2.

| Requisito | Evidencia en FIA |
|---|---|
| Backend y ORM | Spring Boot, entidades JPA, repositorios y perfiles Oracle/demo. |
| CRUD | Cursos: creación, consulta, edición y eliminación. |
| Objetos relacionados | Plan–Curso y Carga–Detalle–Bloque horario. |
| Operación transaccional | Registro/actualización de carga con validación de cruces y rollback. |
| Consultas | Plan, ciclo, búsqueda, semestre, estado, fechas, orden y resumen. |
| Aspectos transversales | Errores HTTP, CORS y correlación navegador–servidor. |
| Contrato REST | Swagger UI y OpenAPI, generados desde controladores y DTO. |
| Límites de módulos | Prueba ModularityTests y acceso de carga a PlanesApi. |

## Ejecutar y mostrar

Desde la carpeta FIA-LP2, con Java 17 o superior y Maven:

```powershell
mvn test
mvn package
java -jar target/fia-academico-1.0.0.jar --spring.profiles.active=demo
```

Interfaz: http://localhost:8080/ . Swagger: http://localhost:8080/swagger-ui.html . Contrato: http://localhost:8080/v3/api-docs . En Swagger, abrir una operación GET y utilizar Try it out / Execute para consultar datos.

Para la instancia Oracle ya configurada, mantener Docker Desktop iniciado y utilizar el perfil docker. No repetir el DDL sobre un esquema existente ni eliminar el volumen para actualizar el código.

```powershell
docker compose up -d
docker compose ps
java -jar target/fia-academico-1.0.0.jar --spring.profiles.active=docker
```

## Exposición en tres partes

1. Joseph Rodrigo: problema, alcance FIA, las dos pantallas y arquitectura (navegador → controlador → servicio → repositorio → base de datos). Mostrar Plan de estudios y Swagger.
2. Jusephy Dalbert: registrar una carga con detalles, explicar validaciones y demostrar un conflicto con rollback. Usar una base de ensayo para crear datos de prueba.
3. Frank Vladimir: mostrar pruebas, filtros, CORS y correlación. Comparar el requestId del error con X-Request-ID y el log. Cerrar con evidencias y limitaciones.

## Pendientes que requieren evidencia del equipo

- Verificar esta entrega contra la instancia Oracle del equipo: una prueba con H2 no demuestra Oracle.
- Confirmar correspondencia con el diseño ADS y el esquema de BD2.
- Proporcionar repositorio, número de equipo y topics indicados por el docente; registrar aportes reales.
- Publicar la documentación en el destino elegido y conservar su URL.
- Si existe una nueva tarea o rúbrica posterior a Unidad 1, incorporarla antes de afirmar cumplimiento total.

La existencia de archivos de documentación o ejemplos no acredita por sí sola aprobación docente, publicación ni pruebas exitosas. Los resultados de esta revisión se registran por separado.
